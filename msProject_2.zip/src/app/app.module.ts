import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppRoutingModule } from './app-routing.module';
import { AutoCompleteModule } from "primeng/autocomplete";
import { TableModule } from "primeng/table";
import { TabViewModule } from 'primeng/tabview';
import { AppLayoutModule } from './layout/app.layout.module';
import { FormsModule } from '@angular/forms';
import { ToolbarModule } from 'primeng/toolbar';
import { ButtonModule } from 'primeng/button';
import { MessagesModule } from 'primeng/messages';
import { MessageModule } from 'primeng/message';
import { MultiSelectModule } from 'primeng/multiselect';
import { ToastModule } from 'primeng/toast';
import { ConfirmDialogModule } from 'primeng/confirmdialog';
import { ConfirmPopupModule } from 'primeng/confirmpopup';
import { RatingModule } from 'primeng/rating';
import { DropdownModule } from "primeng/dropdown";
import { SliderModule } from 'primeng/slider';


import { AppComponent } from './app.component';
import { ResourceDevelopmentComponent } from './resource-development/resource-development.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { ResourceSkillsComponent } from './resource-skills/resource-skills.component';

@NgModule({
  declarations: [
    AppComponent,
    ResourceDevelopmentComponent,
    DashboardComponent,
    ResourceSkillsComponent,
  ],
  imports: [
    BrowserModule,
    AppLayoutModule,
    AppRoutingModule,
    AutoCompleteModule,
    FormsModule,
    TableModule,
    TabViewModule,
    ToolbarModule,
    ButtonModule,
    MessagesModule,
    MessageModule,
    MultiSelectModule,
    ToastModule,
    ConfirmDialogModule,
    ConfirmPopupModule,
    RatingModule,
    DropdownModule,
    SliderModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
