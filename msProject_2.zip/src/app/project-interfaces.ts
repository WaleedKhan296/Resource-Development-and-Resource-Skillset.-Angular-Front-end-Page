import { ResourceSkillsComponent } from './resource-skills/resource-skills.component';
import {RatingModule } from 'primeng/rating';
// Interface for a single certificate or training
export interface CertificateOrTraining {
  name: string;
  category: string;
  status: 'new' | 'in-progress' | 'completed';
}

// Interface for a single TduWbt
export interface TduWbt {
  id: number;
  eid: number;
  training_name: string;
  completion_date: Date | null;
  status: 'new' | 'in-progress' | 'completed';
}

// Interface for an Employee resource
export interface Resource {
  //selectedExperienceYears: ExperienceYears[];
  
  id: number;
  name: string;
  department: string;

  // Certificates, Trainings and TduWbts the employee has
  certificates: CertificateOrTraining[];
  trainings: CertificateOrTraining[];
  tduWbts: TduWbt[];
  ResourceSkills: ResourceSkills[];
}

// Interface for a single certificate or training available in the system
export interface CertificateTrainingInfo {
  name: string;
  category: string;
}

export interface TduWbtInfo {
  id: number;
  eid: number;
  training_name: string;
}

export interface ResourceSkills{
  Name:String;
  Category:String;
  ExperienceYears: number|null;
  Rating: number|null;
}