import { Component, OnInit } from '@angular/core';

import { ConfirmationService, MessageService } from 'primeng/api';
import { Rating, RatingModule } from 'primeng/rating';

import { Resource, ResourceSkills } from '../project-interfaces';
import { DataService } from '../data.service';

@Component({
  selector: 'app-resource-skills',
  templateUrl: './resource-skills.component.html',
  styleUrls: ['./resource-skills.component.scss'],
  providers: [ConfirmationService, MessageService],
})
export class ResourceSkillsComponent {
  ResourceSkills: ResourceSkills[] = []; //ResourceSkills: ResourceSkills[]=[];//holds the skills of the selected resource
  resources: Resource[] = []; //holds all the resources
  allResourceSkills: ResourceSkills[] = []; //allResourceSkills: ResourceSkills[]=[];//holds all the skills

  selectedSkill: ResourceSkills | null = null;
  yearsOfExperience: number = 0;
  skillRating: number = 0;

  private _selectedResourceAdvanced?: Resource; //holds the selected resource from the p-autocomplete

  ResourceSkillsInfo: any; //ResourceSkillsInfo: any;//holds selected skill from the p-multiselect

  showResourceSkills: ResourceSkills[] = [];

  get selectedResourceAdvanced(): Resource | undefined {
    return this._selectedResourceAdvanced;
  }
  set selectedResourceAdvanced(value: Resource | undefined) {
    this._selectedResourceAdvanced = value;
    this.updateResourceSkills();
  }

  filteredResources: any[] = [];
  constructor(
    private dataService: DataService,
    private confirmationService: ConfirmationService,
    private messageService: MessageService
  ) {}

  ngOnInit(): void {
    this.resources = this.dataService.getAllResources();
    this.allResourceSkills = this.dataService.getAllResourceSkills();
  }

  ///////////////////////////PAGE HEADER//////////////////////////////

  // Select a resource from the dropdown
  filterResources(event: any) {
    const filtered: any[] = [];
    const query = event.query;
    for (let i = 0; i < this.resources.length; i++) {
      const resource = this.resources[i];
      if (resource.name.toLowerCase().indexOf(query.toLowerCase()) == 0) {
        filtered.push(resource);
      }
    }
    this.filteredResources = filtered;
  }

  ///////////////////////////DASHBOARD//////////////////////////////

  // Used to update the skills when a resource is selected
  private updateResourceSkills() {
    if (this.selectedResourceAdvanced) {
      this.ResourceSkills = this.selectedResourceAdvanced.ResourceSkills;

      // Filter skills which are not in resourceSkills
      this.showResourceSkills = this.allResourceSkills.filter(
        (skills) => !this.ResourceSkills.some((rs) => rs.Name === skills.Name)
      );
    } else {
      this.ResourceSkills = [];

      this.showResourceSkills = this.allResourceSkills;
    }
  }

  deleteSkill(skillToDelete: ResourceSkills) {
    if (this.selectedResourceAdvanced) {
      // Remove the skill from the currently selected resource's skills
      const index = this.selectedResourceAdvanced.ResourceSkills.findIndex(
        (skill) => skill.Name === skillToDelete.Name
      );
      if (index > -1) {
        this.selectedResourceAdvanced.ResourceSkills.splice(index, 1);

        // Update the displayed skills
        this.updateResourceSkills();

        // Display toast message
        this.messageService.add({
          severity: 'success',
          summary: 'Skill Deleted',
          detail: 'Skill deleted successfully',
        });
      }
    }
  }

  confirmDeleteSkill(event: Event, skillToDelete: ResourceSkills) {
    this.confirmationService.confirm({
      key: 'confirmDeleteSkill',
      target: event.target || new EventTarget(),
      message: `Are you sure that you want to delete the skill ${skillToDelete.Name}?`,
      icon: 'pi pi-exclamation-triangle',
      accept: () => {
        this.deleteSkill(skillToDelete);
      },
    });
  }

  loading = false;

  ///////////////////////////ADD RESOURCESKILLS TAB//////////////////////////////

  // Used to add a new skill to the selected resource
  addNewSkill() {
    if (
      this.selectedResourceAdvanced &&
      this.selectedSkill &&
      this.yearsOfExperience > 0
    ) {
      const newSkill: ResourceSkills = {
        Name: this.selectedSkill.Name,
        Category: this.selectedSkill.Category, // or however you'd like to populate this
        ExperienceYears: this.yearsOfExperience,
        Rating: this.skillRating,
      };
      this.selectedResourceAdvanced.ResourceSkills.push(newSkill);

      // Update the showResourceSkills array to remove the added skill
      this.showResourceSkills = this.showResourceSkills.filter(
        (skill) => skill.Name !== this.selectedSkill?.Name
      );

      // Clear the selected skill, years of experience, and rating
      this.selectedSkill = null;
      this.yearsOfExperience = 0;
      this.skillRating = 0;
    }
  }

  // Used to confirm the add skill action
  confirmAddSkill(event: Event) {
    this.confirmationService.confirm({
      key: 'confirmAddSkill',
      target: event.target || new EventTarget(),
      message: `Are you sure that you want to add the skill to ${this.selectedResourceAdvanced?.name}?`,
      icon: 'pi pi-exclamation-triangle',
      accept: () => {
        this.messageService.add({
          severity: 'info',
          summary: 'Skill Added',
          detail: `Skill added to ${this.selectedResourceAdvanced?.name}`,
        });
        this.addNewSkill();
      },
    });
  }
}
