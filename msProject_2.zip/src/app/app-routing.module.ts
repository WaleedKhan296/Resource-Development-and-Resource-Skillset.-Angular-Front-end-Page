import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { AppLayoutComponent } from './layout/app.layout.component';
import { ResourceDevelopmentComponent } from './resource-development/resource-development.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { ResourceSkillsComponent } from './resource-skills/resource-skills.component';

const routes: Routes = [{
  path: '', component: AppLayoutComponent,
  children: [
    { path: '', component: DashboardComponent },
    { path: 'resource-development', component: ResourceDevelopmentComponent },
    {path:'resource-skills' , component: ResourceSkillsComponent}
  ]
}];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
