import { Component, OnInit } from '@angular/core';
import { ConfirmationService, MessageService } from 'primeng/api';

import { CertificateOrTraining, CertificateTrainingInfo, Resource, TduWbt, TduWbtInfo } from '../project-interfaces';
import { DataService } from '../data.service';

@Component({
  selector: 'app-resource-development',
  templateUrl: './resource-development.component.html',
  styleUrls: ['./resource-development.component.scss'],
  providers: [ConfirmationService, MessageService]
})
export class ResourceDevelopmentComponent {
  selectedCertificates: CertificateOrTraining[] = []; //holds the selected certificates from the p-multiselect
  selectedTrainings: CertificateOrTraining[] = []; //holds the selected trainings from the p-multiselect
  selectedTduWbts: TduWbt[] = []; //holds the selected tduwbts from the p-multiselect

  resourceCertifications: CertificateOrTraining[] = []; //holds the certificates of the selected resource
  resourceTrainings: CertificateOrTraining[] = []; //holds the trainings of the selected resource
  resourceTduWbts: TduWbt[] = []; //holds the tduwbts of the selected resource

  resources: Resource[] = []; //holds all the resources
  allCertificates: CertificateTrainingInfo[] = []; //holds all the certificates
  allTrainings: CertificateTrainingInfo[] = []; //holds all the trainings
  allTduWbts: TduWbtInfo[] = []; //holds all the tduwbts
  
  private _selectedResourceAdvanced?: Resource; //holds the selected resource from the p-autocomplete 
  CertificateTrainingInfo: any; //holds the selected certificate or training from the p-multiselect

  showCertificates: CertificateTrainingInfo[] = [];
  showTrainings: CertificateTrainingInfo[] = [];
  showTduWbts: TduWbtInfo[] = [];

  get selectedResourceAdvanced(): Resource | undefined {
    return this._selectedResourceAdvanced;
  }
  set selectedResourceAdvanced(value: Resource | undefined) {
    this._selectedResourceAdvanced = value;
    this.updateCertificationsAndTrainings();
  }

  filteredResources: any[] = [];

  constructor(private dataService: DataService, private confirmationService: ConfirmationService, private messageService: MessageService) { }

  ngOnInit(): void {
    this.resources = this.dataService.getAllResources();
    this.allCertificates = this.dataService.getAllCertificates();
    this.allTrainings = this.dataService.getAllTrainings();
    this.allTduWbts = this.dataService.getAllTduWbts();
  }

  ///////////////////////////PAGE HEADER//////////////////////////////

  // Select a resource from the dropdown
  filterResources(event: any) {
    const filtered: any[] = [];
    const query = event.query;
    for (let i = 0; i < this.resources.length; i++) {
      const resource = this.resources[i];
      if (resource.name.toLowerCase().indexOf(query.toLowerCase()) == 0) {
        filtered.push(resource);
      }
    }
    this.filteredResources = filtered;
  }


  ///////////////////////////DASHBOARD//////////////////////////////

  // Used to get the status class for the resource. The css class will be used to color the status
  getStatusClass(status: string): string {
    if (status === 'completed') {
      return 'status-qualified';
    } else if (status === 'in-progress') {
      return 'status-proposal';
    } else if (status === 'new') {
      return 'status-new';
    } else {
      return '';
    }
  }

  // Used to update the certifications and trainings when a resource is selected
  private updateCertificationsAndTrainings() {
    if (this.selectedResourceAdvanced) {
      this.resourceCertifications = this.selectedResourceAdvanced.certificates;
      this.resourceTrainings = this.selectedResourceAdvanced.trainings;
      this.resourceTduWbts = this.selectedResourceAdvanced.tduWbts;

      // Filter certificates and trainings which are not in resourceCertifications and resourceTrainings
      this.showCertificates = this.allCertificates.filter(cert => !this.resourceCertifications.some(rc => rc.name === cert.name));
      this.showTrainings = this.allTrainings.filter(training => !this.resourceTrainings.some(rt => rt.name === training.name));
      this.showTduWbts = this.allTduWbts.filter(tduWbt => !this.resourceTduWbts.some(rtw => rtw.training_name === tduWbt.training_name));
    } else {
      this.resourceCertifications = [];
      this.resourceTrainings = [];
      this.resourceTduWbts = [];
      this.showCertificates = this.allCertificates;
      this.showTrainings = this.allTrainings;
      this.showTduWbts = this.allTduWbts;
    }
  }

  loading = false;

  ///////////////////////////ASSIGN CERTIFICATIONS TAB//////////////////////////////

  // Used to assign the selected certificates to the selected resource
  assignSelectedCertificates() {
    if (this.selectedResourceAdvanced && this.selectedCertificates.length > 0) {
      // Iterate through each selected certificate and add it to the resource.certificates array
      this.selectedCertificates.forEach((certificate: CertificateOrTraining) => {
        const newCertificate: CertificateOrTraining = {
          name: certificate.name,
          category: '', // The category will be populated later based on the allCertificates array
          status: 'new' // Assuming newly assigned certificates have 'new' status
        };
        // Find the category of the certificate from the allCertificates array
        const foundCertificate = this.allCertificates.find(cert => cert.name === certificate.name);
        if (foundCertificate) {
          newCertificate.category = foundCertificate.category;
        }
        // Push the newCertificate to the resource.certificates array
        this.selectedResourceAdvanced?.certificates.push(newCertificate);
      });
  
      // Clear the selectedCertificates array after assigning the certificates
      this.selectedCertificates = [];
  
      // Update the showCertificates array to remove the assigned certificates
      this.showCertificates = this.showCertificates.filter(cert => !this.selectedResourceAdvanced?.certificates.some(rc => rc.name === cert.name));
    }
  }

  // Used to confirm the assign certificates action
  confirmAssignCertificates(event: Event) {
    this.confirmationService.confirm({
        key: 'confirmAssignCertificates',
        target: event.target || new EventTarget,
        message: `Are you sure that you want to assign selected certifications to ${this.selectedResourceAdvanced?.name}?`,
        icon: 'pi pi-exclamation-triangle',
        accept: () => {
            this.messageService.add({ severity: 'info', summary: 'Certifications Assigned', detail: `New certifications assigned to ${this.selectedResourceAdvanced?.name}` });
            this.assignSelectedCertificates();
        }
    });
  }  

  ///////////////////////////ASSIGN TRAININGS TAB//////////////////////////////

  // Used to assign the selected trainings to the selected resource
  assignSelectedTrainings() {
    if (this.selectedResourceAdvanced && this.selectedTrainings.length > 0) {
      // Iterate through each selected training and add it to the resource.trainings array
      this.selectedTrainings.forEach((training: CertificateOrTraining) => {
        const newTraining: CertificateOrTraining = {
          name: training.name,
          category: '', // The category will be populated later based on the allTrainings array
          status: 'new' // Assuming newly assigned trainings have 'new' status
        };
        // Find the category of the training from the allTrainings array
        const foundTraining = this.allTrainings.find(tr => tr.name === training.name);
        if (foundTraining) {
          newTraining.category = foundTraining.category;
        }
        // Push the newTraining to the resource.trainings array
        this.selectedResourceAdvanced?.trainings.push(newTraining);
      });
  
      // Clear the selectedTrainings array after assigning the trainings
      this.selectedTrainings = [];
  
      // Update the showTrainings array to remove the assigned trainings
      this.showTrainings = this.showTrainings.filter(training => !this.selectedResourceAdvanced?.trainings.some(rt => rt.name === training.name));
    }
  }

  // Used to confirm the assign trainings action
  confirmAssignTrainings(event: Event) {
    this.confirmationService.confirm({
        key: 'confirmAssignTrainings',
        target: event.target || new EventTarget,
        message: `Are you sure that you want to assign selected trainings to ${this.selectedResourceAdvanced?.name}?`,
        icon: 'pi pi-exclamation-triangle',
        accept: () => {
            this.messageService.add({ severity: 'info', summary: 'Trainings Assigned', detail: `New trainings assigned to ${this.selectedResourceAdvanced?.name}` });
            this.assignSelectedTrainings();
        }
    });
  }

  ///////////////////////////ASSIGN TDUWBTS TAB//////////////////////////////

  // Used to assign the selected tduwbts to the selected resource
  assignSelectedTduWbts() {
    if (this.selectedResourceAdvanced && this.selectedTduWbts.length > 0) {
      // Iterate through each selected tduwbt and add it to the resource.tduwbts array
      this.selectedTduWbts.forEach((tduwbt: TduWbt) => {
        const newTduWbt: TduWbt = {
          id: tduwbt.id,
          eid: tduwbt.eid,
          training_name: tduwbt.training_name,
          completion_date: null,
          status: 'new' // Assuming newly assigned tduwbts have 'new' status
        };
        // Push the newTduWbt to the resource.tduwbts array
        this.selectedResourceAdvanced?.tduWbts.push(newTduWbt);
      });
  
      // Clear the selectedTduWbts array after assigning the tduwbts
      this.selectedTduWbts = [];
  
      // Update the showTduWbts array to remove the assigned tduwbts
      this.showTduWbts = this.showTduWbts.filter(tduwbt => !this.selectedResourceAdvanced?.tduWbts.some(rtw => rtw.training_name === tduwbt.training_name));
    }
  }

  // Used to confirm the assign tduwbts action
  confirmAssignTduWbts(event: Event) {
    this.confirmationService.confirm({
        key: 'confirmAssignTduWbts',
        target: event.target || new EventTarget,
        message: `Are you sure that you want to assign selected TDU WBTs to ${this.selectedResourceAdvanced?.name}?`,
        icon: 'pi pi-exclamation-triangle',
        accept: () => {
            this.messageService.add({ severity: 'info', summary: 'TDU WBTs Assigned', detail: `New TDU WBTs assigned to ${this.selectedResourceAdvanced?.name}` });
            this.assignSelectedTduWbts();
        }
    });
  }
}
