import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ResourceDevelopmentComponent } from './resource-development.component';

describe('ResourceDevelopmentComponent', () => {
  let component: ResourceDevelopmentComponent;
  let fixture: ComponentFixture<ResourceDevelopmentComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [ResourceDevelopmentComponent]
    });
    fixture = TestBed.createComponent(ResourceDevelopmentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
