import { Injectable } from '@angular/core';
import { CertificateOrTraining, Resource, CertificateTrainingInfo, TduWbtInfo, ResourceSkills} from './project-interfaces';
import { Type } from '@angular/compiler';



@Injectable({
  providedIn: 'root'
})
export class DataService {
  getAllRatings(): import("primeng/rating").Rating[] {
    throw new Error('Method not implemented.');
  }
  //allResourceSkills: ResourceSkills[];
 // getAllResourceSkills(): ResourceSkills[] {
   // throw new Error('Method not implemented.');
  //}
  
  
  private allCertificates: CertificateTrainingInfo[] = [
    { name: 'Certified Data Analyst (CDA)', category: 'Data Analysis' },
    { name: 'Tableau Desktop Specialist (TDS)', category: 'Data Analysis' },
    { name: 'Oracle Certified Database Administrator (OCDA)', category: 'Database Management' },
    { name: 'Microsoft Certified: Azure Database Administrator Associate', category: 'Database Management' },
    { name: 'Data Science Certification (DSC)', category: 'Data Science' },
    { name: 'AWS Certified Machine Learning - Specialty (AWS-CMLS)', category: 'Data Science' },
    { name: 'Google Certified Data Engineer (GCDE)', category: 'Data Engineering' },
    { name: 'Cloudera Certified Big Data Analyst (CCBDA)', category: 'Data Engineering' },
    { name: 'Microsoft Certified: Azure Data Engineer Associate', category: 'Data Engineering' },
    { name: 'IBM Certified Data Engineer - Big Data', category: 'Data Engineering' },

  ];
  private allTrainings: CertificateTrainingInfo[] = [
    { name: 'Data Analytics Fundamentals', category: 'Data Analysis' },
    { name: 'Advanced Data Visualization Techniques', category: 'Data Analysis' },
    { name: 'Statistical Analysis with R or Python', category: 'Database Management' },
    { name: 'Relational Database Management Systems (RDBMS)', category: 'Database Management' },
    { name: 'Database Administration and Performance Tuning', category: 'Database Management' },
    { name: 'Machine Learning Fundamentals', category: 'Data Science' },
    { name: 'Deep Learning and Neural Networks', category: 'Data Science' },
    { name: 'Data Science with Python or R', category: 'Data Science' },
    { name: 'Big Data Processing with Hadoop', category: 'Data Engineering' },
    { name: 'Data Pipeline Development and Automation', category: 'Data Engineering' },
  ];
  private allTduWbtInfo: TduWbtInfo[] = [
    { id: 1, eid: 1, training_name: 'Data Analytics Fundamentals' },
    { id: 2, eid: 1, training_name: 'Advanced Data Visualization Techniques' },
    { id: 3, eid: 1, training_name: 'Statistical Analysis with R or Python' },
    { id: 4, eid: 1, training_name: 'Relational Database Management Systems (RDBMS)' },
    { id: 5, eid: 1, training_name: 'Database Administration and Performance Tuning' },
    { id: 6, eid: 1, training_name: 'Machine Learning Fundamentals' },
    { id: 7, eid: 1, training_name: 'Deep Learning and Neural Networks' },
    { id: 8, eid: 1, training_name: 'Data Science with Python or R' },
    { id: 9, eid: 1, training_name: 'Big Data Processing with Hadoop' },
    { id: 10, eid: 1, training_name: 'Data Pipeline Development and Automation' },
  ];
  
  private allResourceSkillsInfo: ResourceSkills[]=[
    {Name: 'Unity',Category:'Game Development',ExperienceYears:5, Rating:5},
    {Name: 'Visual Studio Code', Category:'Web Development', ExperienceYears:5, Rating: 4},
    {Name: 'Android Studio', Category:'Android Development', ExperienceYears:5, Rating: 3},
    {Name: 'Adobe Photoshop', Category:'Graphic Designing', ExperienceYears:5, Rating: 2},
    {Name: 'Flutter', Category:'Android Development', ExperienceYears:5, Rating: 1},
    {Name: 'Tableau', Category:'Data Analysis', ExperienceYears:5, Rating: 3},
    {Name: 'Data Scientist', Category:'Data Science', ExperienceYears:5, Rating: 4},
  ];

  private allResourcesInfo: Resource[] =  [
    { id: 1, name: 'Ali Khan', department: 'Database Management', certificates: [
      { name: 'Certified Data Analyst (CDA)', category: 'Data Analysis', status: 'completed' },
    ], trainings: [
      { name: 'Data Analytics Fundamentals', category: 'Data Analysis', status: 'completed' },
      { name: 'Advanced Data Visualization Techniques', category: 'Data Analysis', status: 'in-progress' },
    ], tduWbts: [
      { id: 1, eid: 1, training_name: 'Data Analytics Fundamentals', completion_date: new Date('2021-01-01'), status: 'completed' },
      { id: 2, eid: 1, training_name: 'Advanced Data Visualization Techniques', completion_date: null, status: 'in-progress' },
  ], ResourceSkills:[
    {Name: 'Unity', Category:'Game Development', ExperienceYears:5, Rating: 5},
    {Name: 'Adobe Photoshop', Category:'Graphic Designing', ExperienceYears:5, Rating: 4},
  ] },
    { id: 2, name: 'Ayesha Malik', department: 'Software Development', certificates: [], trainings: [
      { name: 'Database Administration and Performance Tuning', category: 'Database Management', status: 'completed' },
      { name: 'Machine Learning Fundamentals', category: 'Data Science', status: 'in-progress' },
    ], tduWbts: [
      { id: 1, eid: 1, training_name: 'Data Analytics Fundamentals', completion_date: new Date('2021-01-01'), status: 'completed' },
      { id: 2, eid: 1, training_name: 'Advanced Data Visualization Techniques', completion_date: null, status: 'in-progress' },
    ], ResourceSkills:[
      {Name: 'Unity', Category:'Game Development', ExperienceYears:5, Rating: 4},
      {Name: 'Adobe Photoshop', Category:'Graphic Designing', ExperienceYears:5, Rating: 2},
    ] },
    { id: 3, name: 'Hassan Shah', department: 'Sales and Marketing', certificates: [], trainings: [
      { name: 'Data Pipeline Development and Automation', category: 'Data Engineering', status: 'completed' },
      { name: 'Data Science with Python or R', category: 'Data Science', status: 'new' },
      { name: 'Big Data Processing with Hadoop', category: 'Data Engineering', status: 'in-progress'}
    ], tduWbts: [
      { id: 1, eid: 1, training_name: 'Data Analytics Fundamentals', completion_date: new Date('2021-01-01'), status: 'completed' },
      { id: 2, eid: 1, training_name: 'Advanced Data Visualization Techniques', completion_date: null, status: 'in-progress' },
    ], ResourceSkills:[
      {Name: 'Unity', Category:'Game Development', ExperienceYears:5, Rating: 5},
    
    ]},
    { id: 4, name: 'Fatima Ahmed', department: 'Data Analytics', certificates: [
      { name: 'Certified Data Analyst (CDA)', category: 'Data Analysis', status: 'completed' },
      { name: 'Tableau Desktop Specialist (TDS)', category: 'Data Analysis', status: 'completed' },
      { name: 'Oracle Certified Database Administrator (OCDA)', category: 'Database Management', status: 'in-progress' },
      { name: 'Microsoft Certified: Azure Database Administrator Associate', category: 'Database Management', status: 'in-progress' },
      { name: 'Data Science Certification (DSC)', category: 'Data Science', status: 'new' },
    ], trainings: [
      { name: 'Deep Learning and Neural Networks', category: 'Data Science', status: 'completed' },
      { name: 'Data Science with Python or R', category: 'Data Science', status: 'new' },
    ], tduWbts: [
      { id: 1, eid: 1, training_name: 'Data Analytics Fundamentals', completion_date: new Date('2021-01-01'), status: 'completed' },
      { id: 2, eid: 1, training_name: 'Advanced Data Visualization Techniques', completion_date: null, status: 'in-progress' },
    ], ResourceSkills:[
     
      {Name: 'Unity', Category:'Game Development', ExperienceYears:5, Rating: 5},
    ]
  },
    { id: 5, name: 'Usman Khan', department: 'Data Analytics', certificates: [
      { name: 'IBM Certified Data Engineer - Big Data', category: 'Data Engineering', status: 'completed' },
      { name: 'Microsoft Certified: Azure Data Engineer Associate', category: 'Data Engineering', status: 'in-progress' },
    ], trainings: [
      { name: 'Data Pipeline Development and Automation', category: 'Data Engineering', status: 'new' },
    ], tduWbts: [
      { id: 1, eid: 1, training_name: 'Data Analytics Fundamentals', completion_date: new Date('2021-01-01'), status: 'completed' },
      { id: 2, eid: 1, training_name: 'Advanced Data Visualization Techniques', completion_date: null, status: 'in-progress' },
    ], ResourceSkills:[
      {Name: 'Unity', Category:'Game Development', ExperienceYears:5, Rating: 5},
      {Name: 'Android Studio', Category:'Android Development', ExperienceYears:5, Rating: 4},
    ]},
 
  ];
 

  

  getAllCertificates(): CertificateTrainingInfo[] {
    return this.allCertificates;
  }
  getAllTrainings(): CertificateTrainingInfo[] {
    return this.allTrainings;
  }
  getAllTduWbts(): TduWbtInfo[] {
    return this.allTduWbtInfo;
  }
  
getAllResources(): Resource[]{
  return this.allResourcesInfo;
}

getAllResourceSkills(): ResourceSkills[]{
  return this.allResourceSkillsInfo;
}

  constructor() { }

}


